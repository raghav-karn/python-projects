answer = input("Do you want to hear a joke? ")

# affirmative_responses = ["yes", "y"]
# negative_responses = ["no", "n"]

if "y" in answer.lower():
	print("I'm against picketing, but I don't know how to show it.")
	# Mitch Hedburg (RIP)
elif "n" in answer.lower():
	print("Fine.")  
else:
	print("I don't understand.")    