# + plus
# - minus
# / divide
# * multiply
# ** exponentiation
# % modulo
# < less than
# > greater than

print("What is the answer to life, the universe, and everything?", int((40 + 30 - 7) * 2 / 3))

print("Is it true that 5 * 2 > 3 * 4?")
print(5 * 2 > 3 * 4)

print("What is 5 * 2?", 5 * 2)
print("What is 3 * 4?", 3 * 4)