# "since feeling is first" by e. e. cummings
print("since feeling is first")
print("who pays any attention")
print("to the syntax of things")
print("will never wholly kiss you;")
print("wholly to be a fool")
print("while Spring is in the world")

print()

print("my blood approves")
print("and kisses are a better fate")
print("then wisdom")
print("lady i swear by all flowers. Don't cry") # I love this line.
print("—the best gesture of my brain is less then")
print("you're eyelids' flutter which says")

print()

print("we are for each other: than")
print("laugh, leaning back in my arms")
print("for life's not a paragraph")

print()

print("and death i think is no parenthesis")
