# Variable are kust nicknames
# They're plain, lowercase words
# examples: x, y, banana, phone_n_quail

name = "Raghav"
orphan_fee = 200
teddy_bear_fee = 121.80

total = orphan_fee + teddy_bear_fee

print(name, "the total will be", total)
